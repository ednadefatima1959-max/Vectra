// RmrCore.java — Java JNI binding para librmr
// Compilar:
//   javac RmrCore.java
//   javah -jni RmrCore       (gera RmrCore.h para o lado C)
// Rodar:
//   java -Djava.library.path=. RmrCore
//
// JNI é o canal Java↔nativo mais próximo do metal.
// Evita JNI overhead usando tipos primitivos (long, double, byte[]).
// Shadow: ByteBuffer.allocateDirect() aponta para memória fora do GC heap.

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class RmrCore {

    // ── Carrega biblioteca nativa ──
    static {
        try {
            System.loadLibrary("rmr");   // procura librmr.so no java.library.path
        } catch(UnsatisfiedLinkError e) {
            System.err.println("[rmr] librmr.so não encontrada: " + e.getMessage());
        }
    }

    // ── Declarações native: mapeiam direto para símbolos C ──
    public static native String  version();
    public static native long    cycles();
    public static native double  throughput(double bw, double miss, double par);
    public static native double  harmonicProduct(double[] factors);
    public static native byte[]  hash32(byte[] input);
    public static native double  missRateEstimate(byte[] buf, int stride);

    // ── Arena via Direct ByteBuffer (memória fora do GC) ──
    // Não usa JNI para arena — o ByteBuffer direto é o equivalente:
    // sem GC pressure, sem cópia, ponteiro estável.
    public static ByteBuffer arenaAlloc(int bytes) {
        return ByteBuffer.allocateDirect(bytes).order(ByteOrder.nativeOrder());
    }

    // ── I/O Harmônico: T = B × (1-M) × P ──
    public static double ioModel(double bandwidth, double missRate, double parallelism) {
        return throughput(bandwidth, missRate, parallelism);
    }

    // ── Tail-loop: evita stack overflow de recursão profunda ──
    @FunctionalInterface
    public interface Step<S> { S apply(S state); }

    public static <S> S tailLoop(S init, Step<S> fn, int maxIter) {
        S state = init;
        for(int i = 0; i < maxIter && state != null; i++)
            state = fn.apply(state);
        return state;
    }

    // ── Timer de alta resolução ──
    public static class Timer {
        private final long t0 = cycles();
        public long elapsed() { return cycles() - t0; }
    }

    // ── Demo ──
    public static void main(String[] args) {
        System.out.println("rmr: " + version());

        Timer t = new Timer();
        byte[] h = hash32("RAFAELIA-SIGMA-OMEGA".getBytes());
        System.out.printf("hash32: %s%n", bytesToHex(h));
        System.out.println("ciclos: " + t.elapsed());

        System.out.printf("throughput(10000, 0.05, 16) = %.1f MB/s%n",
            ioModel(10000, 0.05, 16));

        System.out.printf("harmonic([0.95,0.99,16]) = %.4f%n",
            harmonicProduct(new double[]{0.95, 0.99, 16}));

        // tail-loop: 1000 iterações sem recursão
        int result = tailLoop(0, s -> s < 1000 ? s + 1 : null, 2000);
        System.out.println("tailLoop result: " + result);
    }

    private static String bytesToHex(byte[] b) {
        if(b == null) return "null";
        StringBuilder sb = new StringBuilder();
        for(byte x : b) sb.append(String.format("%02x", x));
        return sb.toString();
    }
}
