{ RmrCore.pas — Pascal/Delphi/Free Pascal unit
  Estilo Turbo Pascal / Delphi: unit com interface e implementation.
  Chama librmr.so via cdecl external.

  Compilar (Free Pascal):
    fpc RmrCore.pas -k-L../c -k-lrmr

  Conceito Pascal:
    - "unit" = módulo compilado reutilizável (como uma .DLL antes das DLL existirem)
    - external 'librmr' = FFI direto para o símbolo C
    - ShortString/PChar: Pascal gerencia strings diferente de C — usamos PChar para FFI
}

unit RmrCore;

interface

uses SysUtils;

const
  LIBRMR = 'librmr';           { nome da biblioteca dinâmica }
  CACHE_LINE = 64;             { bytes por linha de cache }

{ ── Tipos ── }
type
  THash32    = array[0..31] of Byte;
  TDoubleArr = array of Double;

{ ── FFI: declarações externas (cdecl = convenção C) ── }
function  rmr_version: PChar;           cdecl; external LIBRMR;
function  rmr_cycles: UInt64;           cdecl; external LIBRMR;
function  rmr_throughput(bw, miss, par: Double): Double; cdecl; external LIBRMR;
function  rmr_product(v: PDouble; n: Integer): Double;   cdecl; external LIBRMR;
procedure rmr_hash32(input: Pointer; len: NativeUInt; out_: PByte); cdecl; external LIBRMR;
function  rmr_miss_rate_estimate(buf: Pointer; sz, stride: NativeUInt): Double; cdecl; external LIBRMR;
function  rmr_arena_new: Pointer;       cdecl; external LIBRMR;
procedure rmr_arena_free(a: Pointer);   cdecl; external LIBRMR;
function  rmr_arena_push(a: Pointer; sz: UInt32): Pointer; cdecl; external LIBRMR;
procedure rmr_arena_clear(a: Pointer);  cdecl; external LIBRMR;

{ ── API Pascal de alto nível ── }
function  RmrVersion: String;
function  RmrCycles: UInt64;
function  RmrHash32(const Data: TBytes): THash32;
function  RmrThroughput(Bandwidth, MissRate, Parallelism: Double): Double;
function  RmrHarmonicProduct(const Factors: TDoubleArr): Double;
function  RmrMissRate(const Data: TBytes; Stride: NativeUInt): Double;

{ TRmrArena: arena RAII — Free chama rmr_arena_free automaticamente }
type
  TRmrArena = class
  private
    FPtr: Pointer;
  public
    constructor Create;
    destructor  Destroy; override;
    function    Alloc(Sz: UInt32): Pointer;
    procedure   Clear;
  end;

{ TRmrTimer: mede ciclos de CPU }
type
  TRmrTimer = record
    T0: UInt64;
    procedure Start;
    function  Elapsed: UInt64;
  end;

implementation

function RmrVersion: String;
begin
  Result := String(rmr_version);
end;

function RmrCycles: UInt64;
begin
  Result := rmr_cycles;
end;

function RmrHash32(const Data: TBytes): THash32;
begin
  FillChar(Result, 32, 0);
  if Length(Data) > 0 then
    rmr_hash32(@Data[0], Length(Data), @Result[0]);
end;

function RmrThroughput(Bandwidth, MissRate, Parallelism: Double): Double;
begin
  Result := rmr_throughput(Bandwidth, MissRate, Parallelism);
end;

function RmrHarmonicProduct(const Factors: TDoubleArr): Double;
begin
  if Length(Factors) = 0 then Exit(1.0);
  Result := rmr_product(@Factors[0], Length(Factors));
end;

function RmrMissRate(const Data: TBytes; Stride: NativeUInt): Double;
begin
  if Length(Data) = 0 then Exit(0.0);
  Result := rmr_miss_rate_estimate(@Data[0], Length(Data), Stride);
end;

{ TRmrArena }
constructor TRmrArena.Create;
begin
  FPtr := rmr_arena_new;
end;

destructor TRmrArena.Destroy;
begin
  if Assigned(FPtr) then rmr_arena_free(FPtr);
  inherited;
end;

function TRmrArena.Alloc(Sz: UInt32): Pointer;
begin
  Result := rmr_arena_push(FPtr, Sz);
end;

procedure TRmrArena.Clear;
begin
  rmr_arena_clear(FPtr);
end;

{ TRmrTimer }
procedure TRmrTimer.Start;
begin
  T0 := rmr_cycles;
end;

function TRmrTimer.Elapsed: UInt64;
begin
  Result := rmr_cycles - T0;
end;

end.
