' rmr_core.bas — QBasic / QB64
' QB64: compila para nativo, pode chamar DECLARE com DLL/SO externa
' Conceito QBasic: DECLARE mapeia função C para BASIC
' Estrutura DATA = shadow do buffer C (mesma memória, nome diferente)
'
' QB64: https://qb64.com — compila este arquivo para executável nativo

DECLARE FUNCTION rmr_version$ ALIAS "rmr_version" LIB "./librmr.so" ()
DECLARE FUNCTION rmr_cycles~&& ALIAS "rmr_cycles" LIB "./librmr.so" ()
DECLARE FUNCTION rmr_throughput# ALIAS "rmr_throughput" LIB "./librmr.so" (bw AS DOUBLE, miss AS DOUBLE, par AS DOUBLE)

' ── Throughput: T = B × (1-M) × P ──
FUNCTION IoThroughput# (bandwidth AS DOUBLE, missRate AS DOUBLE, parallelism AS DOUBLE)
    IoThroughput# = rmr_throughput#(bandwidth, missRate, parallelism)
END FUNCTION

' ── Produto harmônico: Π fatores ──
FUNCTION HarmonicProduct# (factors() AS DOUBLE)
    DIM p AS DOUBLE: p = 1.0
    DIM i AS INTEGER
    FOR i = LBOUND(factors) TO UBOUND(factors)
        p = p * factors(i)
    NEXT i
    HarmonicProduct# = p
END FUNCTION

' ── Tail-loop: sem recursão ──
' Simula tail call como loop (QB não tem tail call)
' fn é simulada como SELECT CASE no estado
FUNCTION TailLoop& (initState AS LONG, maxIter AS LONG)
    DIM s AS LONG: s = initState
    DIM i AS LONG
    FOR i = 1 TO maxIter
        IF s >= 1000 THEN EXIT FOR   ' condição de parada
        s = s + 1
    NEXT i
    TailLoop& = s
END FUNCTION

' ── Demo principal ──
PRINT "rmr: "; rmr_version$()

DIM t0 AS LONG LONG: t0 = rmr_cycles~&&()
DIM result AS DOUBLE
result = IoThroughput#(10000.0, 0.05, 16.0)
DIM t1 AS LONG LONG: t1 = rmr_cycles~&&()

PRINT USING "throughput: ######.# MB/s"; result
PRINT "ciclos: "; t1 - t0

DIM factors(2) AS DOUBLE
factors(0) = 0.95: factors(1) = 0.99: factors(2) = 16.0
PRINT USING "harmonic_product: #.####"; HarmonicProduct#(factors())

PRINT "tail_loop(0,1000): "; TailLoop&(0, 2000)

END
