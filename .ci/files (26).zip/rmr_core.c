/*
 * rmr_core.c — implementação
 * Compila: gcc -O3 -march=native -shared -fPIC -o librmr.so rmr_core.c -lm
 */
#include "rmr_core.h"
#include <stdlib.h>
#include <math.h>
#include <time.h>

const char* rmr_version(void){ return "rmr-polylib-1.0.0"; }

/* Arena heap */
rmr_arena_t* rmr_arena_new(void){
    rmr_arena_t *a = (rmr_arena_t*)aligned_alloc(RMR_CACHE_LINE, sizeof(rmr_arena_t));
    if(a) rmr_arena_init(a);
    return a;
}
void  rmr_arena_free(rmr_arena_t *a){ free(a); }
void* rmr_arena_push(rmr_arena_t *a, uint32_t sz){ return rmr_arena_alloc(a, sz); }
void  rmr_arena_clear(rmr_arena_t *a){ rmr_arena_reset(a); }

/* Hash mínimo portável (FNV-1a 256-bit via 8 palavras) */
void rmr_hash32(const void *in, size_t len, uint8_t out[32]){
    static const uint32_t IV[8]={
        0x6A09E667,0xBB67AE85,0x3C6EF372,0xA54FF53A,
        0x510E527F,0x9B05688C,0x1F83D9AB,0x5BE0CD19};
    uint32_t h[8]; memcpy(h, IV, 32);
    const uint8_t *p = (const uint8_t*)in;
    for(size_t i=0; i<len; i++){
        h[i&7] ^= (uint32_t)p[i];
        h[i&7] = (h[i&7]<<13)|(h[i&7]>>19);
        h[i&7] *= 0x9E3779B9u;
    }
    memcpy(out, h, 32);
}

/* I/O */
double rmr_throughput(double bw, double miss, double par){
    return rmr_io_throughput(bw, miss, par);
}
double rmr_product(const double *v, int n){
    return rmr_harmonic_product(v, n);
}
void rmr_prefetch(const void *p, size_t bytes){
    rmr_prefetch_stream(p, bytes, RMR_CACHE_LINE);
}

/* Ciclos */
uint64_t rmr_cycles(void){ return rmr_tsc(); }

/* Estimativa de miss-rate: acessa buf com stride grande vs pequeno */
double rmr_miss_rate_estimate(const void *buf, size_t sz, size_t stride){
    if(!buf || sz==0 || stride==0) return 0.0;
    const uint8_t *p = (const uint8_t*)buf;
    struct timespec t0, t1;
    /* acesso sequencial (cache-friendly) */
    clock_gettime(CLOCK_MONOTONIC, &t0);
    volatile uint8_t sink=0;
    for(size_t i=0; i<sz; i+=RMR_CACHE_LINE) sink^=p[i];
    clock_gettime(CLOCK_MONOTONIC, &t1);
    double seq_ns = (t1.tv_sec-t0.tv_sec)*1e9+(t1.tv_nsec-t0.tv_nsec);

    /* acesso com stride (miss-cache induzido) */
    clock_gettime(CLOCK_MONOTONIC, &t0);
    for(size_t i=0; i<sz; i+=stride) sink^=p[i%sz];
    clock_gettime(CLOCK_MONOTONIC, &t1);
    double str_ns = (t1.tv_sec-t0.tv_sec)*1e9+(t1.tv_nsec-t0.tv_nsec);

    (void)sink;
    /* razão: quanto mais lento o stride vs seq → maior miss */
    double ratio = str_ns / (seq_ns + 1.0);
    return (ratio > 1.0) ? (1.0 - 1.0/ratio) : 0.0;
}
