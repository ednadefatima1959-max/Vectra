/**
 * rmr_core.js / rmr_core.jsx
 * Node.js: usa ffi-napi para chamar librmr.so diretamente
 * Browser: stubs que apontam para WASM (quando compilado com emcc)
 *
 * Instalar: npm install ffi-napi ref-napi ref-array-napi
 *
 * Conceito JSX: componentes React que expõem métricas RMR em tempo real.
 * O dado nasce no C (librmr), passa pelo Node FFI, chega ao JSX sem cópia.
 */

// ── Node.js: FFI direto para librmr.so ──
let _rmr = null;

function _loadLib() {
  try {
    const ffi   = require('ffi-napi');
    const ref   = require('ref-napi');
    const ArrayType = require('ref-array-napi');
    const DoubleArr = ArrayType(ref.types.double);

    _rmr = ffi.Library('./librmr.so', {
      'rmr_version'            : ['string', []],
      'rmr_cycles'             : ['uint64', []],
      'rmr_throughput'         : ['double', ['double','double','double']],
      'rmr_product'            : ['double', [DoubleArr, 'int']],
      'rmr_miss_rate_estimate' : ['double', ['pointer','size_t','size_t']],
    });
    return true;
  } catch(e) {
    console.warn('[rmr] ffi-napi indisponível, usando stubs:', e.message);
    return false;
  }
}

const _hasLib = _loadLib();

// ── API pública ──

export function version() {
  return _hasLib ? _rmr.rmr_version() : 'rmr-stub-js-1.0';
}

export function cycles() {
  return _hasLib ? Number(_rmr.rmr_cycles()) : performance.now() * 1e6;
}

/** T = B × (1-M) × P — produto harmônico I/O */
export function throughput(bandwidth, missRate, parallelism) {
  if(_hasLib) return _rmr.rmr_throughput(bandwidth, missRate, parallelism);
  return bandwidth * (1 - missRate) * parallelism;   // JS fallback puro
}

/** Π fatores — composição multiplicativa */
export function harmonicProduct(factors) {
  if(_hasLib) {
    const arr = Buffer.alloc(factors.length * 8);
    factors.forEach((v, i) => arr.writeDoubleBE(v, i * 8));
    return _rmr.rmr_product(arr, factors.length);
  }
  return factors.reduce((a, b) => a * b, 1.0);
}

/** Timer de alta precisão */
export class Timer {
  constructor() { this._t0 = cycles(); }
  elapsed()     { return cycles() - this._t0; }
}

// ── JSX: componentes React que expõem métricas RMR ──

import React, { useState, useEffect, useCallback } from 'react';

/** RmrMeter: mostra throughput calculado em tempo real */
export function RmrMeter({ bandwidth = 10000, parallelism = 16 }) {
  const [missRate, setMissRate] = useState(0.05);
  const [result, setResult]    = useState(0);

  useEffect(() => {
    setResult(throughput(bandwidth, missRate, parallelism));
  }, [bandwidth, missRate, parallelism]);

  return (
    <div style={{ fontFamily: 'monospace', padding: 16 }}>
      <h3>RMR I/O Harmônico</h3>
      <label>
        Miss-rate: {(missRate * 100).toFixed(1)}%
        <input type="range" min={0} max={0.5} step={0.01}
          value={missRate}
          onChange={e => setMissRate(parseFloat(e.target.value))}
          style={{ marginLeft: 8 }}
        />
      </label>
      <div style={{ marginTop: 8 }}>
        T = {bandwidth} × (1 - {missRate.toFixed(2)}) × {parallelism}
        = <strong>{result.toFixed(0)} MB/s</strong>
      </div>
      <div style={{ fontSize: '0.8em', color: '#888' }}>
        lib: {version()}
      </div>
    </div>
  );
}

/** RmrPipeline: visualiza a composição de fatores como produto */
export function RmrPipeline({ factors = [0.95, 0.99, 0.98, 16] }) {
  const product = harmonicProduct(factors);
  return (
    <div style={{ fontFamily: 'monospace' }}>
      <div>Fatores: [{factors.join(' × ')}]</div>
      <div>Produto: <strong>{product.toFixed(4)}</strong></div>
      <div style={{ display: 'flex', gap: 4, marginTop: 8 }}>
        {factors.map((f, i) => (
          <div key={i} style={{
            width: 40, height: f * 60,
            background: `hsl(${i*60},70%,50%)`,
            display: 'flex', alignItems: 'flex-end',
            justifyContent: 'center', fontSize: 10
          }}>{f}</div>
        ))}
      </div>
    </div>
  );
}
