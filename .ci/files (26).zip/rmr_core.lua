-- rmr_core.lua
-- Lua binding via LuaJIT FFI (zero-overhead, sem wrapper C)
-- LuaJIT FFI é o mais próximo do metal que Lua chega:
-- chama símbolos C diretamente, sem overhead de Lua C API.
--
-- Requer: LuaJIT 2.x
-- Rodar: luajit rmr_core.lua
--
-- Também funciona com Lua 5.x + lua-ffi (luarocks install luaffi)

local ffi = require("ffi")

-- ── Declarações C (header inline) ──
ffi.cdef[[
  const char* rmr_version(void);
  uint64_t    rmr_cycles(void);
  double      rmr_throughput(double bw, double miss, double par);
  double      rmr_product(const double *v, int n);
  void        rmr_hash32(const void *input, size_t len, uint8_t out[32]);
  double      rmr_miss_rate_estimate(const void *buf, size_t sz, size_t stride);
  void*       rmr_arena_new(void);
  void        rmr_arena_free(void *a);
  void*       rmr_arena_push(void *a, uint32_t sz);
  void        rmr_arena_clear(void *a);
]]

local lib = ffi.load("rmr")

-- ── API Lua ──
local M = {}

function M.version()
  return ffi.string(lib.rmr_version())
end

function M.cycles()
  return tonumber(lib.rmr_cycles())
end

--- hash32(str) → hex string 64 chars
function M.hash32(data)
  local out = ffi.new("uint8_t[32]")
  lib.rmr_hash32(data, #data, out)
  local hex = {}
  for i = 0, 31 do hex[i+1] = string.format("%02x", out[i]) end
  return table.concat(hex)
end

--- throughput: T = B × (1-M) × P
function M.throughput(bw, miss, par)
  return lib.rmr_throughput(bw, miss, par)
end

--- harmonic_product({f1,f2,...}) → Π fi
function M.harmonic_product(factors)
  local arr = ffi.new("double[?]", #factors, factors)
  return lib.rmr_product(arr, #factors)
end

--- miss_rate(str, stride) → [0,1]
function M.miss_rate(data, stride)
  return lib.rmr_miss_rate_estimate(data, #data, stride)
end

-- ── Arena: tabela Lua com gc automático ──
M.Arena = {}
M.Arena.__index = M.Arena

function M.Arena.new()
  local self = setmetatable({}, M.Arena)
  self._ptr = lib.rmr_arena_new()
  -- gc: quando Arena for coletado, libera a memória C
  ffi.gc(self._ptr, lib.rmr_arena_free)
  return self
end

function M.Arena:alloc(sz)
  return lib.rmr_arena_push(self._ptr, sz)
end

function M.Arena:clear()
  lib.rmr_arena_clear(self._ptr)
end

-- ── Timer ──
M.Timer = {}
M.Timer.__index = M.Timer

function M.Timer.new()
  return setmetatable({ t0 = M.cycles() }, M.Timer)
end

function M.Timer:elapsed()
  return M.cycles() - self.t0
end

-- ── tail_loop: substitui tail recursion ──
-- fn(state) → state|nil   nil para parar
function M.tail_loop(state, fn, max_iter)
  local i = 0
  while i < max_iter do
    local next = fn(state)
    if next == nil then break end
    state = next; i = i + 1
  end
  return state
end

-- ── Demo ──
if arg and arg[0]:match("rmr_core") then
  print("rmr: " .. M.version())
  local t = M.Timer.new()
  local h = M.hash32("RAFAELIA-SIGMA-OMEGA")
  print("hash32: " .. h)
  print("ciclos: " .. t:elapsed())
  print(string.format("throughput(10000,0.05,16) = %.1f MB/s",
    M.throughput(10000, 0.05, 16)))
  print(string.format("harmonic([0.95,0.99,16]) = %.4f",
    M.harmonic_product({0.95, 0.99, 16})))
end

return M
