<?php
// rmr_core.php — PHP FFI binding (PHP 7.4+)
// Chama librmr.so via PHP FFI — zero-overhead, sem extensão C necessária.
// Uso: php rmr_core.php

$ffi = FFI::cdef('
    const char* rmr_version(void);
    uint64_t    rmr_cycles(void);
    double      rmr_throughput(double bw, double miss, double par);
    void        rmr_hash32(const void *in, size_t len, uint8_t *out);
    double      rmr_miss_rate_estimate(const void *buf, size_t sz, size_t stride);
', './librmr.so');

function rmr_version(FFI $f): string  { return $f->rmr_version(); }
function rmr_cycles(FFI $f): int      { return $f->rmr_cycles(); }

function rmr_hash32(FFI $f, string $data): string {
    $out = $f->new('uint8_t[32]');
    $f->rmr_hash32($data, strlen($data), $out);
    return bin2hex(FFI::string($out, 32));
}

/** T = B × (1-M) × P */
function rmr_throughput(FFI $f, float $bw, float $miss, float $par): float {
    return $f->rmr_throughput($bw, $miss, $par);
}

// Demo
echo "rmr: " . rmr_version($ffi) . "\n";
$t0 = rmr_cycles($ffi);
echo "hash32: " . rmr_hash32($ffi, "RAFAELIA-SIGMA-OMEGA") . "\n";
echo "ciclos: " . (rmr_cycles($ffi) - $t0) . "\n";
echo "throughput: " . rmr_throughput($ffi, 10000, 0.05, 16) . " MB/s\n";
