# rmr_core.pl — Perl binding via Inline::C / FFI::Platypus
# Requer: cpan FFI::Platypus
# Rodar: perl rmr_core.pl

use strict; use warnings;
use FFI::Platypus;

my $ffi = FFI::Platypus->new(api => 2, lib => ['./librmr.so']);

$ffi->attach('rmr_version'    => []                      => 'string');
$ffi->attach('rmr_cycles'     => []                      => 'uint64');
$ffi->attach('rmr_throughput' => ['double','double','double'] => 'double');
$ffi->attach('rmr_hash32'     => ['opaque','size_t','opaque'] => 'void');

# T = B × (1-M) × P
sub throughput { rmr_throughput(@_) }

# hash32: retorna hex
sub hash32 {
    my ($data) = @_;
    my $out = "\x00" x 32;
    rmr_hash32($data, length($data), $out);
    return unpack("H*", $out);
}

# tail_loop sem recursão
sub tail_loop {
    my ($state, $fn, $max) = @_;
    for(1..$max){ my $n=$fn->($state); last unless defined $n; $state=$n; }
    return $state;
}

print "rmr: " . rmr_version() . "\n";
my $t0 = rmr_cycles();
print "hash32: " . hash32("RAFAELIA-SIGMA-OMEGA") . "\n";
print "ciclos: " . (rmr_cycles() - $t0) . "\n";
printf "throughput: %.1f MB/s\n", throughput(10000, 0.05, 16);
my $r = tail_loop(0, sub { $_[0] < 100 ? $_[0]+1 : undef }, 200);
print "tail_loop: $r\n";
