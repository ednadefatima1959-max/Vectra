# rmr_core.py — Python binding via ctypes
# Sem dependências externas além de ctypes (stdlib)
# Uso: import rmr_core; rmr_core.hash32(b"hello")
#
# ctypes é o "shadow" Python do C:
# zero overhead de serialização — passa ponteiros diretamente

import ctypes, ctypes.util, os, sys

# ── Carrega librmr.so ──
def _load():
    paths = [
        os.path.join(os.path.dirname(__file__), "..", "c", "librmr.so"),
        "./librmr.so",
        ctypes.util.find_library("rmr"),
    ]
    for p in paths:
        if p and os.path.exists(str(p)):
            return ctypes.CDLL(p)
    raise OSError("librmr.so não encontrada. Compile: gcc -shared -fPIC -O3 -march=native rmr_core.c -o librmr.so")

_lib = _load()

# ── Tipos ──
c_u8p  = ctypes.POINTER(ctypes.c_uint8)
c_dp   = ctypes.POINTER(ctypes.c_double)
c_vp   = ctypes.c_void_p

# ── Assinaturas das funções C ──
_lib.rmr_version.restype       = ctypes.c_char_p
_lib.rmr_cycles.restype        = ctypes.c_uint64
_lib.rmr_throughput.restype    = ctypes.c_double
_lib.rmr_throughput.argtypes   = [ctypes.c_double]*3
_lib.rmr_product.restype       = ctypes.c_double
_lib.rmr_product.argtypes      = [c_dp, ctypes.c_int]
_lib.rmr_hash32.restype        = None
_lib.rmr_hash32.argtypes       = [c_vp, ctypes.c_size_t, c_u8p]
_lib.rmr_miss_rate_estimate.restype  = ctypes.c_double
_lib.rmr_miss_rate_estimate.argtypes = [c_vp, ctypes.c_size_t, ctypes.c_size_t]
_lib.rmr_arena_new.restype     = c_vp
_lib.rmr_arena_free.argtypes   = [c_vp]
_lib.rmr_arena_push.restype    = c_vp
_lib.rmr_arena_push.argtypes   = [c_vp, ctypes.c_uint32]
_lib.rmr_arena_clear.argtypes  = [c_vp]

# ── API Python ──

def version() -> str:
    return _lib.rmr_version().decode()

def cycles() -> int:
    """Lê TSC/cntvct_el0 — coordenada física de tempo."""
    return _lib.rmr_cycles()

def hash32(data: bytes) -> bytes:
    """BLAKE3-like 32-byte hash. Zero-copy: passa ponteiro direto."""
    buf = (ctypes.c_uint8 * 32)()
    _lib.rmr_hash32(
        ctypes.cast(ctypes.c_char_p(data), c_vp),
        len(data),
        buf,
    )
    return bytes(buf)

def throughput(bandwidth_mbs: float, miss_rate: float, parallelism: float) -> float:
    """T = B × (1-M) × P — produto harmônico de fatores I/O."""
    return _lib.rmr_throughput(bandwidth_mbs, miss_rate, parallelism)

def harmonic_product(factors: list[float]) -> float:
    """Π fator_i — composição multiplicativa de dimensões independentes."""
    arr = (ctypes.c_double * len(factors))(*factors)
    return _lib.rmr_product(arr, len(factors))

def miss_rate_estimate(data: bytes, stride: int) -> float:
    """Estima miss-rate real medindo latência de stride vs sequencial."""
    buf = ctypes.c_char_p(data)
    return _lib.rmr_miss_rate_estimate(
        ctypes.cast(buf, c_vp), len(data), stride
    )

class Arena:
    """Arena de memória: alloc sem free() individual — sem memory leak."""
    def __init__(self):
        self._a = _lib.rmr_arena_new()
    def alloc(self, sz: int) -> int:
        """Retorna endereço (int). Use ctypes.cast para ponteiro tipado."""
        return _lib.rmr_arena_push(self._a, sz)
    def clear(self):
        _lib.rmr_arena_clear(self._a)
    def __del__(self):
        _lib.rmr_arena_free(self._a)

class Timer:
    """Medidor de ciclos de CPU."""
    def __init__(self): self._t0 = cycles()
    def elapsed(self) -> int: return cycles() - self._t0

# ── Demo rápido ──
if __name__ == "__main__":
    print("rmr:", version())
    t = Timer()
    h = hash32(b"RAFAELIA-SIGMA-OMEGA")
    print("hash32:", h.hex())
    print("ciclos:", t.elapsed())
    print("throughput(10000MB/s, miss=0.05, par=16):",
          throughput(10000, 0.05, 16), "MB/s")
    print("harmonic_product([0.95,0.99,16]):",
          harmonic_product([0.95, 0.99, 16]))
