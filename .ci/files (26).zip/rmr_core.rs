// rmr_core.rs — Rust binding para librmr
// Cargo.toml: [dependencies] (nenhuma)
// Compila: rustc --edition 2021 rmr_core.rs --crate-type lib
//
// Rust é o "shadow seguro" do C:
//   - Arena: Rust garante drop automático (sem leak)
//   - __restrict__: Rust garante por tipo (&mut T exclui &T)
//   - tail call: Rust itera, não recursiona por padrão
//   - inline(always): marca os hot-paths

#![no_std]  // sem std → mais próximo do metal
use core::ffi::{c_void, c_char};

// ── FFI extern: chama librmr.so ──
#[link(name = "rmr")]
extern "C" {
    fn rmr_version()     -> *const c_char;
    fn rmr_cycles()      -> u64;
    fn rmr_throughput(bw: f64, miss: f64, par: f64) -> f64;
    fn rmr_product(v: *const f64, n: i32)           -> f64;
    fn rmr_prefetch(p: *const c_void, bytes: usize);
    fn rmr_hash32(input: *const c_void, len: usize, out: *mut u8);
    fn rmr_miss_rate_estimate(buf: *const c_void, sz: usize, stride: usize) -> f64;
    fn rmr_arena_new()                       -> *mut c_void;
    fn rmr_arena_free(a: *mut c_void);
    fn rmr_arena_push(a: *mut c_void, sz: u32) -> *mut c_void;
    fn rmr_arena_clear(a: *mut c_void);
}

// ── Arena: RAII — sem leak por construção ──
pub struct Arena(*mut c_void);

impl Arena {
    #[inline(always)]
    pub fn new() -> Self {
        Arena(unsafe { rmr_arena_new() })
    }

    #[inline(always)]
    pub fn alloc(&mut self, sz: u32) -> *mut c_void {
        unsafe { rmr_arena_push(self.0, sz) }
    }

    #[inline(always)]
    pub fn clear(&mut self) {
        unsafe { rmr_arena_clear(self.0) }
    }
}

impl Drop for Arena {
    fn drop(&mut self) {
        unsafe { rmr_arena_free(self.0) }
    }
}

// ── Medidor de ciclos: timer de alta precisão ──
pub struct Timer(u64);

impl Timer {
    #[inline(always)]
    pub fn start() -> Self { Timer(unsafe { rmr_cycles() }) }

    #[inline(always)]
    pub fn elapsed(&self) -> u64 { unsafe { rmr_cycles() } - self.0 }
}

// ── Hash 32 bytes ──
#[inline(always)]
pub fn hash32(input: &[u8]) -> [u8; 32] {
    let mut out = [0u8; 32];
    unsafe {
        rmr_hash32(
            input.as_ptr() as *const c_void,
            input.len(),
            out.as_mut_ptr(),
        );
    }
    out
}

// ── I/O Harmônico: T = B × (1-M) × P ──
// Produto de fatores independentes — cada dimensão multiplica
#[inline(always)]
pub fn throughput(bandwidth: f64, miss_rate: f64, parallelism: f64) -> f64 {
    unsafe { rmr_throughput(bandwidth, miss_rate, parallelism) }
}

#[inline(always)]
pub fn harmonic_product(factors: &[f64]) -> f64 {
    unsafe { rmr_product(factors.as_ptr(), factors.len() as i32) }
}

// ── Prefetch: alimenta o pipeline antes do miss ──
#[inline(always)]
pub fn prefetch(data: &[u8]) {
    unsafe { rmr_prefetch(data.as_ptr() as *const c_void, data.len()) }
}

// ── Miss-rate: mede o custo real do stride ──
#[inline(always)]
pub fn miss_rate(buf: &[u8], stride: usize) -> f64 {
    unsafe {
        rmr_miss_rate_estimate(
            buf.as_ptr() as *const c_void,
            buf.len(),
            stride,
        )
    }
}

// ── Tail-loop: substitui tail recursion ──
// f retorna Some(state) para continuar, None para parar
#[inline(always)]
pub fn tail_loop<S, F: Fn(S) -> Option<S>>(init: S, f: F, max: usize) -> S {
    let mut state = init;
    let mut i = 0;
    while i < max {
        match f(state) {
            Some(next) => { state = next; i += 1; }
            None => break,
        }
    }
    state
}
