' rmr_core.vbs — VBScript binding
' VBScript não tem FFI direto. Estratégia:
'   1. Chama rmr via Shell (processo filho) com args
'   2. Ou usa COM: CreateObject("WScript.Shell") + stdout pipe
'   3. Em ASP clássico: Server.CreateObject + DLL COM wrapper
'
' Para ASP/VBScript com DLL COM (modo produção):
'   rmr_core.dll registrada com regsvr32
'   Set rmr = Server.CreateObject("RmrLib.Core")
'
' Para VBScript standalone (cscript.exe):

Option Explicit

' ── Stub: chama rmr_cli.exe via Shell e captura stdout ──
Function RmrExec(cmd As String) As String
    Dim sh: Set sh = CreateObject("WScript.Shell")
    Dim ex: Set ex = sh.Exec("rmr_cli.exe " & cmd)
    RmrExec = ex.StdOut.ReadAll()
    Set ex = Nothing: Set sh = Nothing
End Function

' ── T = B × (1-M) × P — implementado em VBScript puro ──
Function IoThroughput(bandwidth, missRate, parallelism)
    IoThroughput = bandwidth * (1.0 - missRate) * parallelism
End Function

' ── Produto harmônico de array ──
Function HarmonicProduct(factors)
    Dim p: p = 1.0
    Dim i
    For i = 0 To UBound(factors)
        p = p * factors(i)
    Next
    HarmonicProduct = p
End Function

' ── Tail-loop: sem recursão ──
Function TailLoop(initState, maxIter)
    Dim s: s = initState
    Dim i
    For i = 1 To maxIter
        If s >= 1000 Then Exit For
        s = s + 1
    Next
    TailLoop = s
End Function

' ── Demo ──
WScript.Echo "rmr via VBScript"
WScript.Echo "throughput(10000,0.05,16) = " & IoThroughput(10000, 0.05, 16) & " MB/s"

Dim f(2): f(0)=0.95: f(1)=0.99: f(2)=16.0
WScript.Echo "harmonic_product = " & HarmonicProduct(f)
WScript.Echo "tail_loop(0,2000) = " & TailLoop(0, 2000)

' ── ASP Clássico (inline) ──
' <%
' Dim rmr: Set rmr = Server.CreateObject("RmrLib.Core")
' Response.Write rmr.Throughput(10000, 0.05, 16)
' Set rmr = Nothing
' %>
