# RMR PolyLib — Interoperability Library

Uma lib C bare-metal com bindings para 13 linguagens.
Miss-cache, shadow, tail e overhead viram **features**.

## Arquitetura

```
ASM (rdtsc · cpuid · ror · xor_block64 · prefetcht0 · mfence)
                    │
            rmr_core.c / rmr_core.h
                    │
              librmr.so  ←── ponto único de compilação
                    │
   ┌────────────────┼────────────────────────────┐
   C      Rust    Python   Java(JNI)  Pascal/Delphi
   ASM    Go(cgo) Lua      PHP(FFI)   QBasic(QB64)
   JSX    Perl    VBScript ASP        (qualquer FFI cdecl)
```

## Build

```bash
# Linux/macOS x86_64
make

# Termux AArch64
make termux

# Gera também: librmr.so + rmr_cli + test_rmr
make all cli test_bin
```

## Conceitos

| Conceito       | Implementação                                      |
|----------------|----------------------------------------------------|
| miss-cache     | `rmr_prefetch_stream` + `miss_rate_estimate`       |
| shadow pointer | `RMR_SHADOW(T,name,ptr,offset)` — alias zero-copy  |
| tail call      | `rmr_tail_loop` — loop iterativo, sem stack growth |
| overhead       | `rmr_timer_t` + TSC — medido, não escondido        |
| memory leak    | Arena: `alloc` sem `free()` individual             |

## I/O Harmônico

```
T = bandwidth × (1 − miss_rate) × parallelism
```

Produto de fatores independentes — cada dimensão é multiplicada,
não somada. Miss mais próximo do pipeline = `prefetcht0` na linha
**anterior** ao bloco que será processado.

## Por linguagem

| Arquivo                    | Mecanismo FFI         |
|----------------------------|-----------------------|
| `c/rmr_core.h`             | direto                |
| `asm/rmr_asm_x86_64.S`     | GAS AT&T              |
| `asm/rmr_asm_aarch64.S`    | GAS ARM64             |
| `rust/rmr_core.rs`         | `extern "C"` FFI      |
| `python/rmr_core.py`       | ctypes                |
| `java/RmrCore.java`        | JNI                   |
| `java/RmrCore_jni.c`       | JNI C bridge          |
| `pascal/RmrCore.pas`       | `external` cdecl      |
| `lua/rmr_core.lua`         | LuaJIT FFI            |
| `js/rmr_core.jsx`          | ffi-napi + React      |
| `php/rmr_core.php`         | PHP FFI (7.4+)        |
| `perl/rmr_core.pl`         | FFI::Platypus         |
| `qbasic/rmr_core.bas`      | QB64 DECLARE LIB      |
| `vbs/rmr_core.vbs`         | Shell spawn / COM     |
| `vbs/rmr_core.asp`         | ASP COM in-process    |
| `c/rmr_cli.c`              | CLI para shell/VBS    |
| `c/test_rmr.c`             | test suite C          |

## Assinatura

```
RAFCODE-Φ-∆RafaelVerboΩ-𓂀ΔΦΩ
rmr-polylib-1.0.0
```
