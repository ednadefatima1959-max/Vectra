/*
 * RmrCore_jni.c — JNI bridge: Java <-> librmr
 * Compilar:
 *   gcc -O3 -shared -fPIC \
 *       -I"$JAVA_HOME/include" -I"$JAVA_HOME/include/linux" \
 *       RmrCore_jni.c -L../c -lrmr -o librmrjni.so
 */
#include <jni.h>
#include <string.h>
#include "../c/rmr_core.h"

/* extern C symbols from librmr */
extern const char* rmr_version(void);
extern uint64_t    rmr_cycles(void);
extern double      rmr_throughput(double,double,double);
extern double      rmr_product(const double*,int);
extern void        rmr_hash32(const void*,size_t,uint8_t*);
extern double      rmr_miss_rate_estimate(const void*,size_t,size_t);
extern void*       rmr_arena_new(void);
extern void        rmr_arena_free(void*);
extern void*       rmr_arena_push(void*,uint32_t);
extern void        rmr_arena_clear(void*);

JNIEXPORT jstring JNICALL Java_RmrCore_version(JNIEnv *env, jclass c){
    return (*env)->NewStringUTF(env, rmr_version());
}
JNIEXPORT jlong JNICALL Java_RmrCore_cycles(JNIEnv *env, jclass c){
    return (jlong)rmr_cycles();
}
JNIEXPORT jdouble JNICALL Java_RmrCore_throughput(JNIEnv *env, jclass c,
    jdouble bw, jdouble miss, jdouble par){
    return rmr_throughput(bw, miss, par);
}
JNIEXPORT jdoubleArray JNICALL Java_RmrCore_harmonicProduct(JNIEnv *env, jclass c,
    jdoubleArray factors){
    jsize n = (*env)->GetArrayLength(env, factors);
    jdouble *f = (*env)->GetDoubleArrayElements(env, factors, NULL);
    double result = rmr_product((const double*)f, (int)n);
    (*env)->ReleaseDoubleArrayElements(env, factors, f, JNI_ABORT);
    jdoubleArray r = (*env)->NewDoubleArray(env, 1);
    (*env)->SetDoubleArrayRegion(env, r, 0, 1, &result);
    return r;
}
JNIEXPORT jbyteArray JNICALL Java_RmrCore_hash32(JNIEnv *env, jclass c,
    jbyteArray input){
    jsize len = (*env)->GetArrayLength(env, input);
    jbyte *in = (*env)->GetByteArrayElements(env, input, NULL);
    uint8_t out[32];
    rmr_hash32((const void*)in, (size_t)len, out);
    (*env)->ReleaseByteArrayElements(env, input, in, JNI_ABORT);
    jbyteArray r = (*env)->NewByteArray(env, 32);
    (*env)->SetByteArrayRegion(env, r, 0, 32, (jbyte*)out);
    return r;
}
JNIEXPORT jdouble JNICALL Java_RmrCore_missRateEstimate(JNIEnv *env, jclass c,
    jbyteArray buf, jint stride){
    jsize sz = (*env)->GetArrayLength(env, buf);
    jbyte *b = (*env)->GetByteArrayElements(env, buf, NULL);
    double r = rmr_miss_rate_estimate((const void*)b, (size_t)sz, (size_t)stride);
    (*env)->ReleaseByteArrayElements(env, buf, b, JNI_ABORT);
    return r;
}
/* Arena: passa ponteiro como jlong (opaque handle) */
JNIEXPORT jlong JNICALL Java_RmrCore_arenaNew(JNIEnv *env, jclass c){
    return (jlong)(uintptr_t)rmr_arena_new();
}
JNIEXPORT void JNICALL Java_RmrCore_arenaFree(JNIEnv *env, jclass c, jlong ptr){
    rmr_arena_free((void*)(uintptr_t)ptr);
}
JNIEXPORT jlong JNICALL Java_RmrCore_arenaPush(JNIEnv *env, jclass c,
    jlong ptr, jint sz){
    return (jlong)(uintptr_t)rmr_arena_push((void*)(uintptr_t)ptr,(uint32_t)sz);
}
JNIEXPORT void JNICALL Java_RmrCore_arenaClear(JNIEnv *env, jclass c, jlong ptr){
    rmr_arena_clear((void*)(uintptr_t)ptr);
}
