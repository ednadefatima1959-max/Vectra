/*
 * rmr_cli.c — CLI wrapper para librmr
 * Usado por VBScript/Shell via process spawn
 * Build: gcc -O2 rmr_cli.c -L. -lrmr -Wl,-rpath,. -lm -o rmr_cli
 *
 * Comandos:
 *   rmr_cli version
 *   rmr_cli hash   <string>
 *   rmr_cli cycles
 *   rmr_cli throughput <bw> <miss> <par>
 *   rmr_cli product    <f1> <f2> ... <fN>
 *   rmr_cli miss       <stride>    (lê stdin)
 */
#include "rmr_core.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern const char* rmr_version(void);
extern uint64_t    rmr_cycles(void);
extern double      rmr_throughput(double,double,double);
extern double      rmr_product(const double*,int);
extern void        rmr_hash32(const void*,size_t,uint8_t*);

static void print_hex(const uint8_t *b, int n){
    for(int i=0;i<n;i++) printf("%02x",b[i]);
    printf("\n");
}

int main(int argc, char **argv){
    if(argc < 2){ fprintf(stderr,"uso: rmr_cli <cmd> [args]\n"); return 1; }

    if(!strcmp(argv[1],"version")){
        printf("%s\n", rmr_version());

    } else if(!strcmp(argv[1],"hash") && argc >= 3){
        uint8_t out[32];
        rmr_hash32(argv[2], strlen(argv[2]), out);
        print_hex(out, 32);

    } else if(!strcmp(argv[1],"cycles")){
        printf("%lu\n", rmr_cycles());

    } else if(!strcmp(argv[1],"throughput") && argc >= 5){
        double bw   = atof(argv[2]);
        double miss = atof(argv[3]);
        double par  = atof(argv[4]);
        printf("%.6f\n", rmr_throughput(bw, miss, par));

    } else if(!strcmp(argv[1],"product") && argc >= 3){
        int n = argc - 2;
        double *f = (double*)malloc(n * sizeof(double));
        for(int i=0;i<n;i++) f[i] = atof(argv[2+i]);
        printf("%.6f\n", rmr_product(f, n));
        free(f);

    } else {
        fprintf(stderr, "comando desconhecido: %s\n", argv[1]);
        return 2;
    }
    return 0;
}
