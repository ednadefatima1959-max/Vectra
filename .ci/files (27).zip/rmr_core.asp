<%
' rmr_core.asp — ASP Classic wrapper para RmrLib COM
' Requer: rmr_core.dll registrada com regsvr32 rmr_core.dll
' IIS: Application Pool com permissao para COM in-process
Option Explicit

' ── Carrega COM object ──
Dim rmr
On Error Resume Next
Set rmr = Server.CreateObject("RmrLib.Core")
If Err.Number <> 0 Then
    Response.Write "RmrLib.Core nao encontrada: " & Err.Description
    Response.End
End If
On Error GoTo 0

' ── Funcoes helper ──
Function IoThroughput(bw, miss, par)
    IoThroughput = rmr.Throughput(bw, miss, par)
End Function

Function HarmonicProduct(factors)
    HarmonicProduct = rmr.Product(factors)
End Function

Function Hash32Hex(data)
    Hash32Hex = rmr.Hash32Hex(data)
End Function

' ── Demo output ──
Response.ContentType = "text/plain"
Response.Write "rmr: " & rmr.Version & vbCrLf
Response.Write "throughput(10000,0.05,16): " & IoThroughput(10000,0.05,16) & " MB/s" & vbCrLf
Response.Write "hash32: " & Hash32Hex("RAFAELIA-SIGMA-OMEGA") & vbCrLf

Set rmr = Nothing
%>
