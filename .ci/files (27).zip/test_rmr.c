/*
 * test_rmr.c — test suite completo para librmr
 * Build: gcc -O2 test_rmr.c -L. -lrmr -Wl,-rpath,. -lm -o test_rmr
 */
#include "rmr_core.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int passed=0, failed=0;
#define PASS(msg) do{ printf("  [PASS] %s\n",msg); passed++; }while(0)
#define FAIL(msg) do{ printf("  [FAIL] %s\n",msg); failed++; }while(0)
#define CHECK(cond,msg) do{ if(cond) PASS(msg); else FAIL(msg); }while(0)

static void test_version(void){
    printf("\n── version ──\n");
    const char *v = rmr_version();
    printf("  %s\n", v);
    CHECK(v && strlen(v) > 0, "version non-empty");
}

static void test_cycles(void){
    printf("\n── cycles (TSC/cntvct) ──\n");
    uint64_t a = rmr_cycles();
    volatile int x=0; for(int i=0;i<10000;i++) x+=i;
    uint64_t b = rmr_cycles();
    printf("  t0=%lu  t1=%lu  delta=%lu cycles\n", a, b, b-a);
    CHECK(b > a, "cycles monotonic");
    (void)x;
}

static void test_hash32(void){
    printf("\n── hash32 ──\n");
    uint8_t h1[32], h2[32], h3[32];
    rmr_hash32("hello", 5, h1);
    rmr_hash32("hello", 5, h2);
    rmr_hash32("world", 5, h3);
    printf("  hash(hello): ");
    for(int i=0;i<32;i++) printf("%02x",h1[i]); printf("\n");
    CHECK(memcmp(h1,h2,32)==0, "hash deterministic");
    CHECK(memcmp(h1,h3,32)!=0, "hash distinct inputs");
}

static void test_throughput(void){
    printf("\n── I/O harmonico: T = B*(1-M)*P ──\n");
    double t = rmr_throughput(10000.0, 0.0, 1.0);
    CHECK(t == 10000.0, "throughput miss=0 par=1 = bandwidth");
    t = rmr_throughput(10000.0, 1.0, 16.0);
    CHECK(t == 0.0, "throughput miss=1.0 = 0");
    t = rmr_throughput(10000.0, 0.05, 16.0);
    printf("  throughput(10000,0.05,16) = %.1f MB/s\n", t);
    CHECK(t > 100000.0, "throughput > 100000");
}

static void test_product(void){
    printf("\n── harmonic product Pi ──\n");
    double f1[] = {2.0, 3.0, 4.0};
    double r = rmr_harmonic_product(f1, 3);
    printf("  product([2,3,4]) = %.1f\n", r);
    CHECK(r == 24.0, "product 2*3*4=24");
    double f3[] = {0.95, 0.99, 16.0};
    r = rmr_harmonic_product(f3, 3);
    printf("  product([0.95,0.99,16]) = %.4f\n", r);
    CHECK(r > 14.0 && r < 16.0, "product in range");
}

static void test_arena(void){
    printf("\n── arena (no free per alloc) ──\n");
    rmr_arena_t *a = rmr_arena_new();
    CHECK(a != NULL, "arena_new");
    void *p1 = rmr_arena_push(a, 128);
    CHECK(p1 != NULL, "arena_push 128");
    void *p2 = rmr_arena_push(a, 256);
    CHECK(p2 != NULL && p2 != p1, "arena_push 256 distinct");
    rmr_arena_clear(a);
    void *p3 = rmr_arena_push(a, 128);
    CHECK(p3 == p1, "arena_clear resets to start");
    rmr_arena_free(a);
    PASS("arena_free");
}

static void test_shadow(void){
    printf("\n── shadow pointer ──\n");
    uint8_t block[128];
    memset(block, 0xAB, 128);
    RMR_SHADOW(uint32_t, cv,  block, 0);
    RMR_SHADOW(uint8_t,  buf, block, 32);
    CHECK((void*)cv  == (void*)block,      "shadow cv  offset=0");
    CHECK((void*)buf == (void*)(block+32), "shadow buf offset=32");
    CHECK(*cv == 0xABABABABu, "shadow reads same memory");
    PASS("zero-copy shadow");
}

static void test_tail_loop(void){
    printf("\n── tail loop (sem recursao) ──\n");
    typedef struct { int v; } St;
    St s = {0};
    int step(void *p){ St *st=(St*)p; st->v++; return st->v < 1000 ? 1:0; }
    rmr_tail_loop(step, &s, 2000);
    printf("  tail_loop result: %d\n", s.v);
    CHECK(s.v == 1000, "tail_loop reaches 1000");
}

static void test_miss_rate(void){
    printf("\n── miss-rate estimator ──\n");
    uint8_t *buf = (uint8_t*)malloc(1<<20);
    if(!buf){ FAIL("malloc"); return; }
    for(int i=0;i<(1<<20);i++) buf[i]=(uint8_t)i;
    double m_low  = rmr_miss_rate_estimate(buf, 1<<20, 64);
    double m_high = rmr_miss_rate_estimate(buf, 1<<20, 4096);
    printf("  miss(stride=64)   = %.3f\n", m_low);
    printf("  miss(stride=4096) = %.3f\n", m_high);
    CHECK(m_low  >= 0.0 && m_low  <= 1.0, "miss_low  in [0,1]");
    CHECK(m_high >= 0.0 && m_high <= 1.0, "miss_high in [0,1]");
    free(buf);
}

static void bench_hash(void){
    printf("\n── bench hash32 ──\n");
    uint8_t *buf = (uint8_t*)aligned_alloc(64, 1<<20);
    uint8_t out[32];
    memset(buf, 0x42, 1<<20);
    int reps=2000;
    rmr_timer_t t; rmr_timer_start(&t);
    for(int i=0;i<reps;i++) rmr_hash32(buf, 1<<20, out);
    uint64_t cyc = rmr_timer_elapsed(&t);
    printf("  1 MiB x %d reps: %lu cycles/rep  (~%.0f MB/s @ 3GHz)\n",
        reps, cyc/reps, 3.0e9/(double)(cyc/reps));
    free(buf);
}

int main(void){
    printf("══ RMR PolyLib test suite ══\n");
    test_version();
    test_cycles();
    test_hash32();
    test_throughput();
    test_product();
    test_arena();
    test_shadow();
    test_tail_loop();
    test_miss_rate();
    bench_hash();
    printf("\n══ resultado: %d passed  %d failed ══\n", passed, failed);
    return failed > 0 ? 1 : 0;
}
