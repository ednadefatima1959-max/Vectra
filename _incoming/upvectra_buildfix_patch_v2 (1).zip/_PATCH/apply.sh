#!/usr/bin/env sh
set -eu
TARGET=${1:-.}
cp -f build.gradle "$TARGET/build.gradle"
mkdir -p "$TARGET/.github/workflows"
cp -f .github/workflows/android-build.yml "$TARGET/.github/workflows/android-build.yml"
echo "[OK] applied: build.gradle ext + android-build.yml NDK/local.properties"
