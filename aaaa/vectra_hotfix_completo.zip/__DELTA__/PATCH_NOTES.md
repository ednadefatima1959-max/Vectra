# VECTRA HOTFIX — PATCH NOTES
Autor: ∆RafaelVerboΩ / Instituto Rafael
Data: 2026-04-02

## Arquivos neste ZIP

| Arquivo | Bug | Correção |
|---------|-----|----------|
| `.github/workflows/engine-ci.yml` | B05+B06 | shell:bash no approval-gate + upload arm64 |
| `.github/workflows/termux-orchestrator.yml` | B08 | shell:bash no step de signing |
| `.github/workflows/android-build-manual.yml` | B07 | shell:bash em 4 steps com [[ |
| `.github/workflows/android.yml` | supply-chain | @master → SHA fixado |
| `.github/workflows/build-apk.yml` | NOVO | APK push-triggered limpo |
| `.github/workflows/vectras-ci.yml` | B02 | YAML inválido → reconstruído |
| `.github/workflows/ci.yml` | B09 | só workflow_dispatch → push+PR |

## Como aplicar
Coloque este ZIP em `aaaa/` e faça git push.
O workflow `aaaa-pipeline.yml` aplica tudo automaticamente.
